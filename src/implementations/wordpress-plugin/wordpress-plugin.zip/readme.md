# TAO System requirements

## WordPress plugin

This plugin retrieves the latest system requirements and download URLs from the API (behind a GH-Page) on [oat-sa.github.io/tao-system-requirements](https://oat-sa.github.io/tao-system-requirements). It provides shortcodes for all blocks as well as a stylesheet including all assets. Data will be cached in WP based on `config/config.json#cache:lifetime`.

## Development

If you work on the code make sure you include all vendors in the build. 