<?php

class Builder
{
    public function __construct()
    {
        $this->listFiles();
    }

    private function listFiles()
    {
        $startDir = getcwd();
        $parseDir = dirname(__DIR__);
        $archive = basename($parseDir) . '.zip';
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($parseDir));

        chdir($parseDir);
        $zip = new ZipArchive;
        $zip->open($archive, ZipArchive::CREATE);

        foreach ($iterator as $file) {
            if ($file->isDir()) {
                continue;
            }
            $zip->addFile(ltrim(str_replace($parseDir, '', $file->getPathname()), '\\/'));
        }

        $zip->close();

        rename ($archive, './build/' . basename($archive));

        chdir($startDir);
    }

}

new Builder();