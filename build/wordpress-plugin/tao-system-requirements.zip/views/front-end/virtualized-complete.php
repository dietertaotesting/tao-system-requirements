<section class="<?=key($data)?> tao-system-requirements">
    <h2>Install TAO as a Docker container</h2>
    <?=$data['from-virtualized']['virtualized']?>
</section>