<section class="<?=key($data)?> tao-system-requirements">
    <h2>Source downloads</h2>
    <?=$data['from-source']['source-downloads']?>
    <h2>Server-side requirements</h2>
    <h3>Programming languages</h3>
    <?=$data['from-source']['languages']?>
    <h3>Web servers</h3>
    <?=$data['from-source']['servers']?>
    <h3>Databases</h3>
    <?=$data['from-source']['databases']?>
</section>